"""
EXE 队 3421 轮切轴 - 3 号位早雾 Sakiri(大招起手位).

排轴定位: Q 大招起手(攻击力增益) -> E 聚怪 -> 切哈尼娅.
Q 未转好时用 E 聚怪减防顶上, 不空转. 通过共享模块加载 Exe.py 状态机.
"""

import importlib.util
import sys
from pathlib import Path


def _load_team_module():
    """加载同目录 exe.py 内的全队共享排轴核心."""
    key = "_exe_team_rotation_module"
    cached = sys.modules.get(key)
    if cached is not None:
        return cached
    team_path = Path(__file__).resolve().with_name("exe.py")
    spec = importlib.util.spec_from_file_location(key, team_path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[key] = module
    spec.loader.exec_module(module)
    return module


_team = _load_team_module()

STAGE_ZAOWU = _team.STAGE_ZAOWU
get_rotation = _team.get_rotation
register_rotation_actions = _team.register_rotation_actions
log_stage = _team.log_stage

from src.char.BaseChar import BaseChar
from src.char.Sakiri import Sakiri as StockZaowu
from src.combat.planner import Planner, RoleProfile


class ExeTeamZaowu(_team.RotationMixin, StockZaowu):
    cn_name = "EXE队·早雾"
    en_name = "ExeTeam · Sakiri"
    element = BaseChar.ElementType.RED

    # ---- 排轴时值(按实测微调) ----
    SKILL_ANIMATION_WAIT = 0.8   # E 聚怪后的停顿(兜底分支用)
    ULT_ANIMATION_WAIT = 0.8     # Q 后等攻击力增益生效

    def describe_role(self):
        return RoleProfile(
            role=Planner.Role.SUPPORT,
            max_field_time=0.5,
            combat_start_priority=15,
        )

    def combat_plan(self):
        plan = self.plan()
        self.register_skill(plan)
        self.register_ultimate(plan)
        register_rotation_actions(plan, self)
        plan.entry = self.perform_entry
        return plan

    def perform_entry(self):
        rotation = get_rotation(self.task)
        stage = rotation.stage_for(self)
        log_stage(self, rotation, stage)

        if stage == STAGE_ZAOWU:
            # Q 大招起手(攻击力增益) -> 接 E(聚怪减防) -> 切哈尼娅
            if self.ultimate_available():
                self.click_ultimate()
                self.sleep(self.ULT_ANIMATION_WAIT)
            # Q 之后必接一个 E; Q 没好的情况下这里也起到兜底作用
            self.click_skill()
            self.sleep(self.SKILL_ANIMATION_WAIT)
            self.rotation_next()
        else:
            self.logger.warning("[exe-team] Zaowu unexpected entry, fallback")
            if self.skill_available():
                self.click_skill()
            if self.ultimate_available():
                self.click_ultimate()
            self.rotation_retry()

