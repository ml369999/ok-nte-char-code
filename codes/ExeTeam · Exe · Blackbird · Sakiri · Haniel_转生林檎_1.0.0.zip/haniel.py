"""
EXE 队 3421 轮切轴 - 4 号位哈尼娅 Haniel(增伤辅助).

排轴定位: E -> Q 增伤 -> 切回 EXE 站场收割.
通过共享模块加载 Exe.py 的排轴状态机.
"""

import importlib.util
import sys
from pathlib import Path


def _load_team_module():
    """加载同目录 exe.py 内的全队共享排轴核心."""
    key = "_exe_team_rotation_module"
    cached = sys.modules.get(key)
    if cached is not None:
        return cached
    team_path = Path(__file__).resolve().with_name("exe.py")
    spec = importlib.util.spec_from_file_location(key, team_path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[key] = module
    spec.loader.exec_module(module)
    return module


_team = _load_team_module()

STAGE_HANIYA = _team.STAGE_HANIYA
get_rotation = _team.get_rotation
register_rotation_actions = _team.register_rotation_actions
log_stage = _team.log_stage

from src.char.BaseChar import BaseChar
from src.char.Haniel import Haniel as StockHaniya
from src.combat.planner import Planner, RoleProfile


class ExeTeamHaniya(_team.RotationMixin, StockHaniya):
    cn_name = "EXE队·哈尼娅"
    en_name = "ExeTeam · Haniel"
    element = BaseChar.ElementType.BLUE

    # ---- 排轴时值(按实测微调) ----
    SKILL_ANIMATION_WAIT = 0.3   # E 后停顿
    ULT_ANIMATION_WAIT = 0.5     # Q 后等增伤生效再切 EXE

    def describe_role(self):
        return RoleProfile(
            role=Planner.Role.SUPPORT,
            max_field_time=0.5,
            combat_start_priority=10,
        )

    def combat_plan(self):
        plan = self.plan()
        self.register_skill(plan)
        self.register_ultimate(plan)
        register_rotation_actions(plan, self)
        plan.entry = self.perform_entry
        return plan

    def perform_entry(self):
        rotation = get_rotation(self.task)
        stage = rotation.stage_for(self)
        log_stage(self, rotation, stage)

        if stage == STAGE_HANIYA:
            self.click_skill()
            self.sleep(self.SKILL_ANIMATION_WAIT)
            self.click_ultimate()
            self.sleep(self.ULT_ANIMATION_WAIT)
            self.rotation_next()
        else:
            self.logger.warning("[exe-team] Haniya unexpected entry, fallback")
            if self.skill_available():
                self.click_skill()
            if self.ultimate_available():
                self.click_ultimate()
            self.rotation_retry()
