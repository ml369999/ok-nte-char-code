"""
EXE 队 3421 轮切轴 - 2 号位黑羽 Blackbird(关键辅助位).

排轴定位: E 挂「失乐羽」印记 -> 有 Q 则 Q(吃增益 + 即瞬环合喂给 EXE)
-> 立刻切哈尼娅/EXE. 通过共享模块加载 Exe.py 的排轴状态机.
"""

import importlib.util
import sys
from pathlib import Path


def _load_team_module():
    """加载同目录 exe.py 内的全队共享排轴核心."""
    key = "_exe_team_rotation_module"
    cached = sys.modules.get(key)
    if cached is not None:
        return cached
    team_path = Path(__file__).resolve().with_name("exe.py")
    spec = importlib.util.spec_from_file_location(key, team_path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[key] = module
    spec.loader.exec_module(module)
    return module


_team = _load_team_module()

STAGE_HEIYU = _team.STAGE_HEIYU
get_rotation = _team.get_rotation
register_rotation_actions = _team.register_rotation_actions
log_stage = _team.log_stage

from src.char.BaseChar import BaseChar
from src.char.Blackbird import Blackbird as StockHeiyu
from src.combat.planner import Planner, RoleProfile


class ExeTeamHeiyu(_team.RotationMixin, StockHeiyu):
    cn_name = "EXE队·黑羽"
    en_name = "ExeTeam · Blackbird"
    element = BaseChar.ElementType.BLUE

    # ---- 排轴时值(按实测微调) ----
    SKILL_ANIMATION_WAIT = 0.2   # E 挂印记后的停顿
    ULT_ANIMATION_WAIT = 0.5     # Q 后等即瞬环合喂给 EXE
    SKILL_RETRY_TIMEOUT = 1.5    # E 未就绪时的最长等待

    def describe_role(self):
        return RoleProfile(
            role=Planner.Role.SUB_DPS,
            max_field_time=0.5,
            combat_start_priority=5,
        )

    def combat_plan(self):
        plan = self.plan()
        self.register_skill(plan)
        self.register_ultimate(plan)
        register_rotation_actions(plan, self)
        plan.entry = self.perform_entry
        return plan

    def perform_entry(self):
        rotation = get_rotation(self.task)
        stage = rotation.stage_for(self)
        log_stage(self, rotation, stage)

        if stage == STAGE_HEIYU:
            # 硬性要求: 切 EXE 前必须放出一个 E(挂失乐羽印记)
            if not self.click_skill():
                self.task.wait_until(
                    self.skill_available,
                    post_action=self.click_with_interval,
                    time_out=self.SKILL_RETRY_TIMEOUT,
                )
                if not self.click_skill():
                    # E 始终没就绪: 不推进轮转, 让 planner 下轮再试,
                    # 避免把没印记的 EXE 切进场
                    self.logger.warning(
                        "[exe-team] Heiyu E not ready, hold rotation"
                    )
                    self.rotation_retry()
                    return
            self.sleep(self.SKILL_ANIMATION_WAIT)

            if self.ultimate_available():
                self.click_ultimate()
                self.sleep(self.ULT_ANIMATION_WAIT)
                self.normal_attack_until_can_switch()
            self.rotation_next()
        else:
            self.logger.warning("[exe-team] Heiyu unexpected entry, fallback")
            if self.skill_available():
                self.click_skill()
            if self.ultimate_available():
                self.click_ultimate()
            self.rotation_retry()

