"""
EXE 队 3421 轮切轴 - 1 号位EXE Exe(主C)

轴(每轮一次, 早雾->哈尼娅->黑羽->EXE 循环):
  1 早雾  : Q 大招起手(攻击力增益) -> E聚怪 -> 切哈尼娅
  2 哈尼娅: E -> Q 增伤 -> 切黑羽
  3 黑羽  : E 挂失乐羽印记 -> (有 Q 则 Q 喂即瞬环合) -> 切 EXE
  4 EXE   : Q 进方程构建 -> E 导出残像 -> 长按普攻(纵深侵入)
            -> 连点普攻攒帧 -> 二段 E 补残像 -> 站场普攻到环合满 -> 切回早雾

兼容说明:
- 软件尚未内置 EXE 角色类, 本文件继承 BaseChar 通用基类,
  全部手法走基类通用接口(click_skill / click_ultimate /heavy_attack 等).
可复制一份至\data\apps\ok-nte\working\src\char下
"""

import sys

from src.char.BaseChar import BaseChar
from src.combat.planner import Planner, RoleProfile

# ---------------------------------------------------------------------------
# 阶段定义(全队共享)
# ---------------------------------------------------------------------------
STAGE_EXE = "exe"
STAGE_HEIYU = "heiyu"
STAGE_ZAOWU = "zaowu"
STAGE_HANIYA = "haniya"

# 轮转顺序: 早雾(大招起手) -> 哈尼娅(E接Q增伤) -> 黑羽(挂印记/喂环合) -> EXE(站场)
LOOP_STAGES = (
    STAGE_ZAOWU,
    STAGE_HANIYA,
    STAGE_HEIYU,
    STAGE_EXE,
)

# 注意: 这里的类名必须与各队友文件里定义的类名完全一致
STAGE_OWNER = {
    STAGE_EXE: "ExeTeamExe",
    STAGE_HEIYU: "ExeTeamHeiyu",
    STAGE_ZAOWU: "ExeTeamZaowu",
    STAGE_HANIYA: "ExeTeamHaniya",
}

ROTATION_ATTR = "exe_rotation"


def _no_priority_ready():
    return False


class ExeRotation:
    """固定轮转的阶段指针, 挂在 task.exe_rotation 上."""

    def __init__(self):
        self.reset()

    def reset(self):
        # 每场战斗从早雾大招起手(先铺攻击力增益, 再进 EXE 站场)
        self.cursor = 0
        self.rounds = 0

    def current_stage(self):
        return LOOP_STAGES[self.cursor]

    def current_owner(self):
        return STAGE_OWNER[self.current_stage()]

    def stage_for(self, char):
        """当前阶段归属该角色时返回阶段名, 否则返回 None(脱轴)."""
        if self.current_owner() == type(char).__name__:
            return self.current_stage()
        return None

    def advance(self):
        self.cursor = (self.cursor + 1) % len(LOOP_STAGES)
        if self.cursor == 0:
            self.rounds = self.rounds + 1


def get_rotation(task):
    """获取(或惰性创建)本场战斗的排轴状态机."""
    rotation = getattr(task, ROTATION_ATTR, None)
    if rotation is None:
        rotation = ExeRotation()
        setattr(task, ROTATION_ATTR, rotation)
    return rotation


def find_teammate(char, owner_name):
    """按角色类名在队伍里查找队友对象."""
    for teammate in char.task.chars:
        if teammate is not None and type(teammate).__name__ == owner_name:
            return teammate
    return None


def request_rotation_next(char, rotation, reason):
    """请求切到下一阶段归属角色(必须在 action/entry 帧内调用)."""
    target = find_teammate(char, rotation.current_owner())
    if target is None:
        char.logger.warning(
            "exe rotation: teammate %s not found" % rotation.current_owner()
        )
        return
    char.logger.info(
        "[exe-team] %s done -> stage=%s owner=%s rounds=%s"
        % (
            type(char).__name__,
            rotation.current_stage(),
            rotation.current_owner(),
            rotation.rounds,
        )
    )
    char.combat_context.request_switch(target, reason=reason)


class RotationMixin:
    """收尾动作: 登记为 plan action, 在 action 帧内推进排轴并发布切人请求."""

    def rotation_next(self):
        rotation = get_rotation(self.task)
        rotation.advance()
        request_rotation_next(self, rotation, "exe rotation -> next slot")
        return True

    def rotation_retry(self):
        """脱轴兜底: 不推进状态机, 只请求切回当前阶段归属角色."""
        rotation = get_rotation(self.task)
        request_rotation_next(self, rotation, "exe rotation -> retry current slot")
        return True


def register_rotation_actions(plan, char):
    """把两个收尾动作登记进 plan, 并让它们不参与切人评分."""
    plan.register(
        char.rotation_next,
        name=type(char).__name__ + "_rotation_next",
        tags={Planner.ActionTag.DEFAULT_ACTION},
        reason="advance exe rotation",
        priority_ready=_no_priority_ready,
    )
    plan.register(
        char.rotation_retry,
        name=type(char).__name__ + "_rotation_retry",
        tags={Planner.ActionTag.DEFAULT_ACTION},
        reason="retry exe rotation without advancing",
        priority_ready=_no_priority_ready,
    )


def log_stage(char, rotation, stage):
    char.logger.info(
        "[exe-team] %s entry stage=%s current=%s rounds=%s"
        % (
            type(char).__name__,
            stage,
            rotation.current_stage(),
            rotation.rounds,
        )
    )


# ---------------------------------------------------------------------------
# 1 号位: EXE(站场主 C, 基于 BaseChar 兜底)
# ---------------------------------------------------------------------------
class ExeTeamExe(RotationMixin, BaseChar):
    cn_name = "EXE队·EXE"
    en_name = "ExeTeam · Exe"
    # 若 ElementType 没有 EXE 对应的属性值, 可先注释掉本行
    # element = BaseChar.ElementType.DARK

    # ---- 排轴时值(全部按实测微调) ----
    ULT_ANIMATION_WAIT = 0.5      # Q 进方程构建后的动画停顿
    SKILL_ANIMATION_WAIT = 0.3    # E 导出残像后的停顿
    HEAVY_DURATION = 1.2          # 长按普攻「纵深侵入」时长
    ATTACK_DURATION = 2.0         # 连点普攻攒帧时长
    ATTACK_INTERVAL = 0.2         # 连点间隔
    SKILL2_ANIMATION_WAIT = 0.4   # 二段 E 补残像停顿
    FIELD_TIME = 6.0              # 站场普攻上限(until_cycle_full 提前结束)
    SKILL_RECHECK_TIMEOUT = 1.5   # E 未就绪重查超时

    def describe_role(self):
        return RoleProfile(
            role=Planner.Role.MAIN_DPS,
            max_field_time=3.0,
            combat_start_priority=0,
        )

    def combat_policies(self):
        """每场战斗重置排轴, 并锁定固定切人(屏蔽自动改切)."""
        rotation = get_rotation(self.task)
        rotation.reset()
        self.logger.info("[exe-team] rotation reset, retarget disabled")
        self.task.find_element_reaction_target = self._no_retarget

    def _no_retarget(self, source_char):
        return None

    def combat_plan(self):
        plan = self.plan()
        self.register_skill(plan, add_tags=Planner.ActionTag.HIGH_PRIORITY)
        self.register_ultimate(plan)
        register_rotation_actions(plan, self)
        plan.entry = self.perform_entry
        return plan

    def perform_entry(self):
        rotation = get_rotation(self.task)
        stage = rotation.stage_for(self)
        log_stage(self, rotation, stage)

        if stage == STAGE_EXE:
            self.perform_burst_combo()
            self.rotation_next()
        else:
            self.logger.warning("[exe-team] Exe unexpected entry, fallback")
            if self.ultimate_available():
                self.click_ultimate()
            if self.skill_available():
                self.click_skill()
            self.rotation_retry()

    def perform_burst_combo(self):
        """
        站场爆发循环(视频 4:29-5:20 手法):
        Q 进方程构建 -> E 导出残像 -> 长按普攻 -> 连点攒帧
        -> 二段 E 补残像 -> 站场普攻到环合满.
        """
        self.click_ultimate()
        self.sleep(self.ULT_ANIMATION_WAIT)

        if not self.click_skill():
            self.task.wait_until(
                self.skill_available,
                post_action=self.click_with_interval,
                time_out=self.SKILL_RECHECK_TIMEOUT,
            )
            self.click_skill()
        self.sleep(self.SKILL_ANIMATION_WAIT)

        # 长按普攻「纵深侵入」(heavy_attack 内部已处理按住/松开)
        self.heavy_attack(self.HEAVY_DURATION)

        # 连点普攻攒帧: click 不接受时长参数, 必须用循环
        start = self.clock.now()
        while self.clock.now() - start < self.ATTACK_DURATION:
            self.click()
            self.sleep(self.ATTACK_INTERVAL)

        if self.skill_available():
            self.click_skill()
            self.sleep(self.SKILL2_ANIMATION_WAIT)

        self.continues_normal_attack(
            self.FIELD_TIME,
            interval=self.ATTACK_INTERVAL,
            until_cycle_full=True,
        )
        return True



# ---------------------------------------------------------------------------
# 共享模块注册(队友文件通过 TEAM_MODULE_KEY 加载本模块)
# ---------------------------------------------------------------------------
TEAM_MODULE_KEY = "_exe_team_rotation_module"
sys.modules[TEAM_MODULE_KEY] = sys.modules[__name__]
